<h1><strong>ANTES DE TUDO LEMBRE-SE: COPIAR CÓDIGOS NÃO É PROGRAMAR! USE APENAS PARA FINS EDUCATIVOS E QUE APRENDA COM ESSE REPOSITÓRIO!!!</strong></h1>

## Descrição

Fiz esse repositório para ajudar vocês a iniciar no Discord.js v14, espero que todos gostem e possam se beneficiar disso!

## Instalação
Para instalar os arquivos desse repositório você pode usar git clone:

```md
git clone https://github.com/xYuriizin/Slash-Commands-Discord.js-v14.git
```
ou apenas instalar os arquivos!

## Modo de uso
```diff
+ após você ter instalado todos os arquivos corretamente, entre no arquivo "index.js" na raíz do projeto e insira seu token onde é informado!
- em seguida vá ao arquivo index.js que se encontra dentro da pasta "handler" e coloque o ID do seu servidor.
+ após isso abra seu terminal e use "npm i" para instalar todas as dependências necessárias e depois "node index.js" e será avisado se tudo ocorrer bem!
```

## Requisitos
Saber o minimo de JavaScript, ter algum conhecimento da livraria Discord.js e só!

## Licença
Você é livre para copiar e editar o código a vontade! Mas lembre-se <strong>VENDER O CÓDIGO É COMPLETAMENTE PROIBIDO!</strong>
